#!/data/data/com.termux/files/usr/bin/bash

# Go to project root
cd ~/novum || exit

# Set Python path so imports work
export PYTHONPATH="$PWD"

# Start Flask server in background
python3 interface/web.py &

# Give Flask a few seconds to start
sleep 2

# Open browser automatically
termux-open-url http://127.0.0.1:5000
